# TODO-List
 - This TODO-List is for people that can check out what they have been doing and what they are going to do later
 - Added more code and more labels for people to write what tasks they want to make
 - Added headline fo people to write by their own what kind of list they want to make
 - Added variables for my input, box and list
 - Made buttons work with click function
 - Added some comments to tell what the different lines does
 - The function and purpose with this TODO-list is for people so they wont forget and just add more tasks they want to do and what they need forexample.
 a shoppinglist or a bucketlist 
 - When the page loades, the account or user will be entered in to the input box to write right away without having to click the box
 - This shows what kind of quests/tasks and list the user want to make
- It will make a list when the tasks are added
- If for example the user accidently add a typo in the task, they can delete the task by clicking "slett" or the delete button
- When user is finished/done with the task, they can check of in the checkbox to make it checked so its done.
- When a task is done, and the checkbox is checked, there will come a line across the task which marks it as done
- Users also have the ability to hit enter instead of clicking the "legg til" button to add a task to the list
 - The max length of number of characters in 1 task is 20
 - A delete all button to remove all the tasks in 1 click
 - Alert that says if the taskbox is empty or not